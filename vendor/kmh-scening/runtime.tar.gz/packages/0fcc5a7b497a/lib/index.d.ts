/** 将 Cordis 插件日志追加到 KMH 私有记录文件。 */
import type { Context } from "@deepseek-ai/cordis";
import schema from "@deepseek-ai/schemastery";
/** Cordis 插件名称。 */
export declare const name = "kmh-runtime-log";
/** 部署指定的绝对日志路径。 */
export declare const Config: schema<Schemastery.ObjectS<NoInfer<{
    file: schema<string, string, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    file: schema<string, string, "defined">;
}>>, "plain">;
/** 校验后的日志配置。 */
export type Config = ReturnType<typeof Config>;
/**
 * 注册一个随插件释放的日志导出器；每条记录同步刷新到磁盘，写入错误撤回导出器并向调用者传播。
 * @param ctx - 拥有导出器的 Cordis 上下文。
 * @param config - 私有日志文件的绝对路径。
 */
export declare function apply(ctx: Context, config: Config): void;
